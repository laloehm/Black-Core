<div class="row cookies p-5" id="cookies">
    <i class="far fa-times-circle" id="close-cookies"></i>
    <div class="col-lg-8">
        <p>Utilizamos cookies para personalizar contenido y anuncios, proporcionar funciones de redes sociales y analizar nuestro tráfico. También compartimos información sobre cómo usted utiliza nuestro sitio con nuestros socios de redes sociales, de publicidad y de analítica.</p>
    </div>
    <div class="col-lg-4 d-flex justify-content-center align-items-center">
        <div class="aceptar-cookies">
            Aceptar cookies
        </div>
    </div>
</div>

<div class="users-online text-center">
    <p class="font-aqua usuarios-activos m-0"> <span class="span-green random" id="random"></span> <br> Usuarios <br> Invirtiendo</p>
</div>