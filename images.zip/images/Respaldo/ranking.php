<div class="row justify-content-center align-items-center" id="ranking">
    <p class="text-white m-0">Ver más</p>
    <i class="fas fa-angle-down wow bounce ocultar" data-wow-iteration="infinite" data-wow-duration="2s"></i>
</div>
<!-- Dos -->
<div class="" id="table">
    <table class="table">
        <tbody class="ultimos">
            <tr>
                <td class="avatar"><img src="images/Reconocimientos/Avatars/4.jpg" class="img-fluid" alt=""></td>
                <td class="posicion-primeros">4</td>
                <td class="borde-primero">seb.arana</td>
                <td>83%</td>
            </tr>
            <tr>
                <td class=""><img src="images/Reconocimientos/Avatars/10.jpg" class="img-fluid" width="60" alt=""></td>
                <td class="">5</td>
                <td>raul_cantu</td>
                <td>72%</td>
            </tr>
            <tr>
                <td class=""><img src="images/Reconocimientos/Avatars/9.jpg" class="img-fluid" width="60" alt=""></td>
                <td class="">6</td>
                <td>pam-garza</td>
                <td>68%</td>
            </tr>
            <tr>
                <td class=""><img src="images/Reconocimientos/Avatars/8.jpg" class="img-fluid" width="60" alt=""></td>
                <td>7</td>
                <td>emiliog.8</td>
                <td>55%</td>
            </tr>
            <tr>
                <td class=""><img src="images/Reconocimientos/Avatars/3.jpg" class="img-fluid" width="60" alt=""></td>
                <td>8</td>
                <td>_marcel.8</td>
                <td>48%</td>
            </tr>
            <tr>
                <td class=""><img src="images/Reconocimientos/Avatars/2.jpg" class="img-fluid" width="60" alt=""></td>
                <td>9</td>
                <td>karlovelazco</td>
                <td>42%</td>
            </tr>
            <tr>
                <td class=""><img src="images/Reconocimientos/Avatars/1.jpg" class="img-fluid" width="60" alt=""></td>
                <td>10</td>
                <td>ferdelabarrera</td>
                <td>39%</td>
            </tr>
            <!-- <tr>
                <td>11</td>
                <td>castaneyra953</td>
                <td>17%</td>
            </tr>
            <tr>
                <td>12</td>
                <td>anacoudurier</td>
                <td>13%</td>
            </tr>
            <tr>
                <td>13</td>
                <td>sergio_rivera</td>
                <td>12%</td>
            </tr>
            <tr>
                <td>14</td>
                <td>sam.veana</td>
                <td>8%</td>
            </tr>
            <tr>
                <td>15</td>
                <td>alline_nv</td>
                <td>5%</td>
            </tr> -->
        </tbody>
    </table>
</div>






<!-- 


<div class="col-10" id="table">
    <table class="table">
       uno ->
<div class="row">
    <div class="col-1">
        copa
    </div>
    <div class="avatar">
        <img src="images/Elements/Iconos/LEOPOLDO.jpg" alt="">
    </div>
    <div class="col-1">
        <h3>1</h3>
    </div>
    <div class="col">
        <h3>LEOPOLDO ARCIAGA</h3>
    </div>
    <div class="col-2">
        <p>94%</p>
    </div>
</div>

<!-- Dos ->
<div class="row">
    <div class="col-1">

    </div>
    <div class="avatar">
        <img src="images/Elements/Iconos/MARTINA.jpg" alt="">
    </div>
    <div class="col-1">
        <h3>1</h3>
    </div>
    <div class="col">
        <h3>MARTINA VENEGAS</h3>
    </div>
    <div class="col-2">
        <p>82%</p>
    </div>
</div>

<!-- Tres ->
<div class="row">
    <div class="col-1">
    </div>
    <div class="avatar">
        <img src="images/Elements/Iconos/WILLIAM.jpg" alt="">
    </div>
    <div class="col-1">
        <h3>1</h3>
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-2">
        <p>71%</p>
    </div>
</div>

<!-- Cuatro ->
<div class="row">
    <div class="offset-1 col-2">
        4
    </div>
    <div class="col">
        <h3>MARIANO ZINCO</h3>
    </div>
    <div class="col-3">
        <p>52%</p>
    </div>
</div>

<!-- 5 ->
<div class="row">
    <div class="offset-1 col-2">
        5
    </div>
    <div class="col">
        <h3>TOMAS YORK</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 6 ->
<div class="row">
    <div class="offset-1 col-2">
        6
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 7 ->
<div class="row">
    <div class="offset-1 col-2">
        7
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 8 ->
<div class="row">
    <div class="offset-1 col-2">
        8
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 9 ->
<div class="row">
    <div class="offset-1 col-2">
        9
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 10 ->
<div class="row">
    <div class="offset-1 col-2">
        10
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 11 ->
<div class="row">
    <div class="offset-1 col-2">
        11
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!-12 ->
<div class="row">
    <div class="offset-1 col-2">
        12
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!-13 ->
<div class="row">
    <div class="offset-1 col-2">
        13
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 14 ->
<div class="row">
    <div class="offset-1 col-2">
        14
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>

<!- 15 ->
<div class="row">
    <div class="offset-1 col-2">
        15
    </div>
    <div class="col">
        <h3>WILLIAM MARTINEZ</h3>
    </div>
    <div class="col-3">
        <p>94%</p>
    </div>
</div>


</table>
</div>




-->